#!/bin/bash
cd "$(dirname "$0")" || exit 1
PORT="${PORT:-8080}"
echo "Golden Hour (offline) starting at http://localhost:$PORT/"
python3 -m http.server "$PORT" --bind 127.0.0.1 &
SERVER_PID=$!
sleep 1
open "http://localhost:$PORT/"
trap "kill $SERVER_PID 2>/dev/null" EXIT
wait $SERVER_PID
