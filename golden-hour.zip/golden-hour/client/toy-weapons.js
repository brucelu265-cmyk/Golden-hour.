export const WEAPON_CAMPAIGN = Object.freeze({
  bvid: "BV1drWB6wEyr", aid: 117609609626997, author: "49800433",
  title: "B站点开就能玩，随时随地 COD，使命在召唤！5V5射击实机",
});
const INITIAL = new Set(["ar", "pistol"]);

// Grants come only from a fresh official SDK response in the current session.
// Saved booleans, clicked links and cloud loadouts never grant weapon access.
export class ToyWeaponAccess extends EventTarget {
  constructor(account, campaign = WEAPON_CAMPAIGN) {
    super(); this.account = account; this.campaign = campaign; this.generation = 0;
    this.state = Object.freeze({ status: "unlocked", unlocked: true, following: true, liked: true, coined: true, favorited: true, author: true, message: "全部枪械已开放，可直接使用。" });
    let previous = account.state.status;
    account.addEventListener("change", () => {
      const status = account.state.status;
      if (status === "authorizing" && previous !== status) {
        this.generation++; this.request = null;
        this.change({ status: "idle", unlocked: false, following: false, liked: false, coined: false, favorited: false, author: false, message: "正在切换 Toy 身份…" });
      }
      previous = status;
      if (status === "ready" && this.state.status === "idle") void this.check();
    });
  }
  change(patch) { this.state = Object.freeze({ ...this.state, ...patch }); this.dispatchEvent(new Event("change")); }
  canUse(weapon) { return true; }
  check({ refresh = false } = {}) {
    // No social verification required: every weapon is available to everyone.
    this.change({ status: "unlocked", unlocked: true, following: true, liked: true, coined: true, favorited: true, author: true, message: "全部枪械已开放，可直接使用。" });
    return Promise.resolve(this.state);
  }
  verify({ refresh = false } = {}) {
    if (this.request) return this.request;
    if (!refresh && !["idle", "login"].includes(this.state.status)) return Promise.resolve(this.state);
    if (!this.account.state.authenticated || !this.account.sdk) {
      this.change({ status: "login", unlocked: false, message: "请先在正式 B站 Toy 页面同步 B站身份，再校验解锁条件。初始两把枪可直接使用。" });
      return Promise.resolve(this.state);
    }
    const token = this.generation, sdk = this.account.sdk;
    this.change({ status: "checking", message: "正在通过 Toy 校验关注与视频三连状态…" });
    const operation = (async () => {
      try {
        const supported = await Promise.all([sdk.isSupport("getAuthorRelation"), sdk.isSupport("getVideoUserActions")]);
        if (supported.some(value => value !== true)) throw Error("unsupported");
        const [relation, videos] = await Promise.all([
          sdk.getAuthorRelation(), sdk.getVideoUserActions({ videos: [{ bvid: this.campaign.bvid }] }),
        ]);
        if (token !== this.generation) return this.state;
        if (relation?.status !== "ok" || typeof relation.data?.isFollowing !== "boolean") throw Error(relation?.status || "unavailable");
        const author = relation.data.isAuthor === true;
        const item = videos?.items?.find(item => item.bvid === this.campaign.bvid && item.aid === this.campaign.aid);
        if (!author && (!["ok", "partial"].includes(videos?.status) || item?.status !== "ok" ||
          typeof item.liked !== "boolean" || !Number.isInteger(item.coinCount) || item.coinCount < 0 || typeof item.favorited !== "boolean")) throw Error(videos?.status || "unavailable");
        const following = relation.data.isFollowing, liked = item?.liked === true, coined = item?.coinCount > 0, favorited = item?.favorited === true;
        // An SDK-verified creator cannot follow/coin their own video; allow the
        // owner to test their work. Other identities require all four conditions.
        const unlocked = author || following && liked && coined && favorited;
        this.change({ status: unlocked ? "unlocked" : "locked", unlocked, following, liked, coined, favorited, author,
          message: author ? "Toy 已核验作者本人，可测试全部武器。" : unlocked ? "关注与视频三连已核验，VESPER 9 和 M12 已解锁。"
            : "完成下方条件后，返回点击「重新校验」。仅打开页面不会解锁。" });
      } catch (error) {
        if (token !== this.generation) return this.state;
        const status = String(error?.message || error?.type || "");
        this.change({ status: "unavailable", unlocked: false, message: status.includes("unsupported")
          ? "当前容器不支持互动状态校验，请在 B站 App 或桌面正式 Toy 页面重试。初始两把枪仍可使用。"
          : "暂时无法核验互动状态，请确认已登录并稍后手动重试。初始两把枪仍可使用。" });
      }
      return this.state;
    })();
    this.request = operation;
    operation.finally(() => { if (this.request === operation) this.request = null; });
    return operation;
  }
  navigate(type) {
    const sdk = this.account.sdk;
    if (!sdk?.navigate) { this.change({ message: "请在 B站 Toy 页面打开作者或视频。" }); return Promise.resolve(false); }
    // Invoke immediately in the user's click turn; never perform social actions.
    let promise;
    try { promise = sdk.navigate({ type: type === "author" ? "space" : "video", id: type === "author" ? this.campaign.author : this.campaign.bvid }); }
    catch (error) { promise = Promise.reject(error); }
    return Promise.resolve(promise).then(() => true, () => { this.change({ message: "页面打开失败，请在 B站 App 内重试。" }); return false; });
  }
}

export function installWeaponGate({ access, engine, progression, authorize }) {
  const { menus } = engine.ctx.hud;
  let returnPage = "gunsmith";
  const page = menus._page("toy-unlock", `
    <header class="topbar"><button class="backb" data-nav data-act="unlock-back">‹ <span>返回</span></button><h2>武器解锁</h2><span class="online-mode">KR-7 · STRIX 9 初始可用</span></header>
    <div class="online-layout toy-unlock-layout">
      <section class="online-commands">
        <div class="sech"><span>扩展军械</span><span>VESPER 9 / M12</span></div>
        <h3>关注作者 ＋ 视频三连</h3>
        <p>关注本作品作者，并为《随时随地 COD》宣传视频点赞、投币、收藏，即可使用另外两把主武器。</p>
        <p data-unlock-status role="status"></p>
        <button class="nv" data-nav data-act="unlock-author"><b>去关注作者</b><em>B站主页 ›</em></button>
        <button class="nv" data-nav data-act="unlock-video"><b>打开宣传视频</b><em>点赞 · 投币 · 收藏 ›</em></button>
        <button class="nv primary" data-nav data-act="unlock-check"><b>重新校验</b><em>完成后返回点击 ›</em></button>
        <button class="btn" data-nav data-act="unlock-login">同步 B站身份</button>
      </section>
      <section class="online-squad">
        <div class="sech"><span>解锁条件</span><span>TOY 官方校验</span></div>
        <div class="toy-unlock-checks" data-unlock-checks></div>
        <p>不替你自动关注、点赞或投币；请在 B站页面亲自完成。解锁适用于当前 B站账号，本次校验结果不会从其他账号继承。</p>
      </section>
    </div>`);
  page.addEventListener("click", event => { const button = event.target.closest("button[data-act]"); if (button && !button.disabled) menus._act(button.dataset.act); });
  const render = () => {
    const state = access.state;
    page.querySelector("[data-unlock-status]").textContent = state.message;
    const list = page.querySelector("[data-unlock-checks]");
    list.replaceChildren();
    for (const [key, text] of [["following", "已关注作者"], ["liked", "宣传视频已点赞"], ["coined", "宣传视频已投币"], ["favorited", "宣传视频已收藏"]]) {
      const row = document.createElement("p");
      row.textContent = `${state[key] ? "✓" : "○"} ${text}`; row.className = state[key] ? "complete" : ""; list.append(row);
    }
    page.querySelector('[data-act="unlock-check"]').disabled = state.status === "checking";
    if (menus.page === "gunsmith") menus._gsRender(false);
  };
  function open() {
    returnPage = menus.page === "gunsmith" ? "gunsmith" : "main";
    menus.go("toy-unlock"); render(); void access.check();
  }
  const act = menus._act;
  menus._act = function (action, direction) {
    if (action === "unlock-back") return this.go(returnPage);
    if (action === "unlock-author") return void access.navigate("author");
    if (action === "unlock-video") return void access.navigate("video");
    if (action === "unlock-check") return void access.check({ refresh: true });
    if (action === "unlock-login") return void authorize({ explicit: true }).then(() => access.check({ refresh: true }));
    return act.call(this, action, direction);
  };
  const back = menus.back;
  menus.back = function () { return this.page === "toy-unlock" ? this.go(returnPage) : back.call(this); };
  const equip = menus._gsEquip;
  menus._gsEquip = function (...args) { if (!access.canUse(this.gs.w)) return open(); return equip.apply(this, args); };
  const renderGun = menus._gsRender;
  menus._gsRender = function (...args) {
    const result = renderGun.apply(this, args);
    if (!access.canUse(this.gs.w)) {
      const button = this.pages.gunsmith.querySelector("#gs-equip");
      button.disabled = false; button.textContent = "关注 ＋ 三连解锁";
    }
    return result;
  };
  const arsenal = engine.ctx.arsenal, reset = arsenal.reset;
  arsenal.reset = function (primary, ...args) {
    if (!access.canUse(primary)) { primary = "ar"; engine.ctx.settings.primary = "ar"; }
    return reset.call(this, primary, ...args);
  };
  progression.setWeaponPolicy(weapon => access.canUse(weapon));
  access.addEventListener("change", () => { progression.refresh(); render(); });
  if (!access.canUse(engine.ctx.settings.primary)) engine.ctx.settings.primary = "ar";
  if (menus.page === "main") menus._refreshMain();
  render();
  return { open };
}
