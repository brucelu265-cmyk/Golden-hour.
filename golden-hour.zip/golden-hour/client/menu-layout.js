// Layout is independent of the chosen combat controls and rendering budget.
// A small desktop window needs the same reflow as an embedded mobile viewport.
export function menuLayout({
  width = 1280, height = 720, coarse = false, mobile = false,
  userAgent = "", platform = "", maxTouchPoints = 0,
} = {}) {
  const tablet = /iPad|Tablet|Android(?!.*Mobile)/i.test(userAgent)
    || (platform === "MacIntel" && maxTouchPoints > 1);
  const phone = !tablet && (mobile || /iPhone|iPod|Android.*Mobile/i.test(userAgent));
  const handheld = tablet || phone || coarse;
  const compact = handheld || width < 1100 || height < 700;
  return {
    device: tablet ? "tablet" : phone ? "phone" : handheld ? "touch" : "desktop",
    layout: !compact ? "desktop" : width >= 700 || (width >= 560 && width > height) ? "wide" : "portrait",
    density: height <= 520 ? "short" : height <= 620 ? "tight" : "standard",
    compact,
  };
}

export function installMenuLayout(win = window, doc = document) {
  const pointer = win.matchMedia("(pointer: coarse)");
  const viewport = win.visualViewport;
  let pending = 0;
  const update = () => {
    pending = 0;
    // Browser bars and the Toy iframe change the usable viewport. Pinch zoom
    // must keep its normal behavior rather than trigger a fresh layout.
    if (viewport?.scale > 1.01) return;
    const width = Math.round(Math.min(win.innerWidth, viewport?.width || win.innerWidth));
    const height = Math.round(Math.min(win.innerHeight, viewport?.height || win.innerHeight));
    const safeStyle = win.getComputedStyle?.(doc.documentElement);
    const safe = side => parseFloat(safeStyle?.getPropertyValue("--menu-safe-" + side)) || 0;
    const result = menuLayout({ width: width - safe("left") - safe("right"), height: height - safe("top") - safe("bottom"), coarse: pointer.matches,
      mobile: win.navigator.userAgentData?.mobile, userAgent: win.navigator.userAgent,
      platform: win.navigator.platform, maxTouchPoints: win.navigator.maxTouchPoints });
    const body = doc.body;
    body.classList.toggle("compact-menu", result.compact);
    body.dataset.menuLayout = result.layout;
    body.dataset.menuDensity = result.density;
    body.dataset.menuDevice = result.device;
    body.style.setProperty("--menu-width", width + "px");
    body.style.setProperty("--menu-height", height + "px");
  };
  const schedule = () => { if (!pending) pending = win.requestAnimationFrame(update); };
  const events = new AbortController();
  for (const type of ["resize", "orientationchange", "pageshow"])
    win.addEventListener(type, schedule, { signal: events.signal });
  viewport?.addEventListener("resize", schedule, { signal: events.signal });
  pointer.addEventListener("change", schedule, { signal: events.signal });
  update();
  return () => { events.abort(); if (pending) win.cancelAnimationFrame(pending); };
}
